-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Авг 05 2021 г., 10:40
-- Версия сервера: 5.7.19
-- Версия PHP: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `mysite-local`
--

-- --------------------------------------------------------

--
-- Структура таблицы `access`
--

CREATE TABLE `access` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `access`
--

INSERT INTO `access` (`id`, `title`) VALUES
(1, 'u'),
(2, 'a');

-- --------------------------------------------------------

--
-- Структура таблицы `messagesUsers`
--

CREATE TABLE `messagesUsers` (
  `id` int(15) NOT NULL,
  `uID` int(15) NOT NULL,
  `messageUser` varchar(350) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE `news` (
  `id` int(15) UNSIGNED NOT NULL,
  `new` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `new`) VALUES
(77, 'Добавлена новая услуга \"Обработка металлов под давлением\"!'),
(78, 'Добавлена новая вакансия \"Слесарь механосборочных работ\"!'),
(93, 'Добавлена новая вакансия \"Шлифовщик по металлу\"!');

-- --------------------------------------------------------

--
-- Структура таблицы `Officials`
--

CREATE TABLE `Officials` (
  `id` int(15) NOT NULL,
  `userid` int(15) NOT NULL,
  `lastName` varchar(75) NOT NULL,
  `firstName` varchar(75) NOT NULL,
  `patronymic` varchar(75) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `official` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `Officials`
--

INSERT INTO `Officials` (`id`, `userid`, `lastName`, `firstName`, `patronymic`, `tel`, `official`) VALUES
(10, 16, 'Литвин', 'Дмитрий', 'Валерьевич', '89122999999', 'Слесарь механосборочных работ'),
(9, 14, 'Казайкин', 'Никита', 'Викторович', '89122791907', 'Слесарь механосборочных работ');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(15) NOT NULL,
  `userid` varchar(15) NOT NULL,
  `service` varchar(70) NOT NULL,
  `dateOrder` varchar(50) NOT NULL,
  `datePerformance` varchar(50) NOT NULL,
  `price` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `userid`, `service`, `dateOrder`, `datePerformance`, `price`) VALUES
(77, '16', 'Долбежные работы', '05.08.2021 10:39:10', 'awgag', 5000),
(78, '16', 'Литьё металлов под давлением', '05.08.2021 10:39:12', 'awgag', 3000),
(79, '16', 'Обработка металлов под давлением', '05.08.2021 10:39:14', 'awgag', 4000);

-- --------------------------------------------------------

--
-- Структура таблицы `services`
--

CREATE TABLE `services` (
  `id` int(15) NOT NULL,
  `title` varchar(70) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `price` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `services`
--

INSERT INTO `services` (`id`, `title`, `description`, `price`) VALUES
(1, 'Литьё металлов под давлением', 'Для промышленного литья используют следующие металлы:<br />\r\n					•	Черные металлы (стали, ковкий, чугун, литейный чугун, чугун с шаровидным<br />\r\n					графитом);<br />\r\n					•	Цветные металлы (медь, латунь и бронза, титан, а также никелевые, алюминиевые<br /> \r\n					и магниевые сплавы);<br />\r\n					•	Редкие и драгоценные металлы (золото, серебро, платина).', 3000),
(33, 'Фрезерная металлообработка', 'Высококвалифицированные мастера осуществят точную фрезерную обработку на мощном оборудовании. Детали изготовляются как по образцу заказчика, так и по предоставленным чертежам.', 3500),
(34, 'Долбежные работы', 'На высокоэффективных станках выполняются долбежные работы различных видов: обработка многогранников, цилиндрических поверхностей, изготовление отверстий в неравнобоких геометрических фигурах.', 5000),
(2, 'Обработка металлов под давлением', 'Наша компания осуществляет услуги обработки металла давлением и  имеет в своем \r\nраспоряжении самое современное станочное оборудование, оснащенное ЧПУ, \r\nа также высококлассных специалистов.', 4000),
(35, 'Токарная обработка металла', 'Изготовить высокоточную деталь с помощью технологии токарной металлообработки. Станки обрабатывают различные виды металла в минимально короткие сроки.', 4500),
(36, 'Дуговая контактная сварка', 'Мы используем современное немецкое оборудования для сварки разных видов металла. Что позволяет нам получать высокую точность конечных сборочных изделий для наших клиентов.', 3000);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(15) UNSIGNED NOT NULL,
  `firstName` varchar(40) NOT NULL,
  `lastName` varchar(40) NOT NULL,
  `patronymic` varchar(40) NOT NULL,
  `address` varchar(40) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `login` varchar(40) NOT NULL,
  `pass` varchar(40) NOT NULL,
  `accessUser` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `firstName`, `lastName`, `patronymic`, `address`, `tel`, `email`, `login`, `pass`, `accessUser`) VALUES
(15, 'Admin', 'Admin', 'Admin', 'New-York', '89999999999', 'therussiangui1010@gmail.com', 'Loginpassword', '7234faae0f9765a358b790d5a207d525', 'a'),
(16, 'Дмитрий', 'Литвин', 'Валерьевич', 'Гагарина 99', '89122999999', 'litvin@mail.ru', 'Litvinlogin', '7c9eb4dadbf7bb0d306f8b79060fbcf1', 'u');

-- --------------------------------------------------------

--
-- Структура таблицы `vacancies`
--

CREATE TABLE `vacancies` (
  `id` int(15) NOT NULL,
  `requirements` varchar(350) NOT NULL,
  `payment` float UNSIGNED NOT NULL,
  `workingconditions` varchar(350) NOT NULL,
  `title` varchar(70) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `vacancies`
--

INSERT INTO `vacancies` (`id`, `requirements`, `payment`, `workingconditions`, `title`) VALUES
(1, 'Токарная обработка деталей.', 30000, 'Работает в цехе или в мастерской.', 'Токарь'),
(2, 'Выполнение механосборочных работ любой сложности.', 35000, 'Как правило, сборка изделий и механизмов производится в помещении.', 'Слесарь механосборочных работ'),
(68, 'Обработка различных изделий на фрезерном станке.', 30000, 'Цех, заводская столовая, медпункт.', 'Фрезеровщик'),
(3, ' Газоэлектросварка', 33000, 'Специально оборудованное помещение, на открытом воздухе, под водой или на высоте.', 'Сварщик'),
(69, 'Шлифование и доводка плоскостей, цилиндрических и конусных наружных и внутренних поверхностей сложных деталей.', 31000, 'Безвредные на шлифовальных станках.', 'Шлифовщик по металлу');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `access`
--
ALTER TABLE `access`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `messagesUsers`
--
ALTER TABLE `messagesUsers`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `Officials`
--
ALTER TABLE `Officials`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tel` (`tel`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `vacancies`
--
ALTER TABLE `vacancies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `access`
--
ALTER TABLE `access`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `messagesUsers`
--
ALTER TABLE `messagesUsers`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `news`
--
ALTER TABLE `news`
  MODIFY `id` int(15) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT для таблицы `Officials`
--
ALTER TABLE `Officials`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT для таблицы `services`
--
ALTER TABLE `services`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(15) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT для таблицы `vacancies`
--
ALTER TABLE `vacancies`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
